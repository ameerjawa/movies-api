var config = {
    apiKey: "AIzaSyByn60QI7M7c4VuECwrOOpN_DF_DGwxwrU",
    authDomain: "imdp-movies.firebaseapp.com",
    databaseURL: "https://imdp-movies-default-rtdb.firebaseio.com/",
    projectId: "imdp-movies",
    storageBucket: "imdp-movies.appspot.com",
    messagingSenderId: "724435766915",
    appId: "1:724435766915:web:c48f0aa2b8b9e64811d5b6",
    measurementId: "G-FE534FFJ2E"
};

export default config