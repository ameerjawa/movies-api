import React from "react";

const AuthUserContext = React.createContext(null); //using React's Context API

export default AuthUserContext;
